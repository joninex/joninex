# hcdrill
HCDecryptor web version (WIP)

The web version of the decryptor lives here.

Currently it can only decrypt HTTP Custom files (.hc), however support for more apps is planned.
